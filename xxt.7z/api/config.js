module.exports = {
    host: "http://www.baidu.com",
    swiperList: [
        "/static/home/1.jpg",
        "/static/home/2.jpg",
        "/static/home/3.jpg",
        "/static/home/4.jpg"
    ],
    notice: "所有签到均已修复，签到失败多点几次签到即可！！！",

    products: [
    ]
};