Page({
    data: {
        img: '/static/img/qqchat.png',
        value: 'qq',
        list: [
          { value: 'qq', label: 'QQ' },
          { value: 'public', label: '公众号' },
          { value: 'wechat', label: '微信' },
        ],
    },

    methods: {
        onChange(e) {
          this.setData({
            value: e.detail.value,
          });
        },
      },

})