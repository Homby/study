import util from '../../../api/util';
import API from '../../../api/api';
import log from '../../../api/log';
import config from '../../../api/config';

Page({
    data: {
        swiperList: config.swiperList,
        notice: config.notice, // 公告
        products: config.products.filter(item => item.appid != util.info.miniProgram.appId),
        config: {
            'notice': {
                speed: 60,
                loop: -1,
                delay: 0,
            },
        },

        img1: 'https://tdesign.gtimg.com/miniprogram/images/example1.png',
        img2: 'https://tdesign.gtimg.com/miniprogram/images/example2.png',
        img3: 'https://tdesign.gtimg.com/miniprogram/images/example3.png',

        courses: [],
        account: {},
    },

    onLoad(options) {
        this.setData({
            'history': util.getStorage('history', []),
        })

        // console.log("获取课程...")
        const accounts = util.getStorage('accounts', []);
        const activeIndex = util.getStorage('activeIndex', -1);
        if (accounts.length == 0) {
            this.setData({
                'courses': [],
                'account': {},
            })
            return;
        }
        const account = accounts[activeIndex];
        const api = new API(account.username, account.password);
        api.getCourse()
            .then(courses => {
                this.setData({
                    'courses': courses,
                    'account': account,
                })
            })
    },

    changeTabbar(e) { // 切换tabbar页面
        wx.switchTab({
            url: `/pages/tabbar-package/${e.detail.value}/${e.detail.value}`,
        })
    },

    navigate(e) { // 进入其他页面
        wx.navigateTo({
            url: e.currentTarget.dataset.url,
        })
    },
    navigate1(e) { // 进入活动列表页面
        const account = this.data.account;
        const classId = e.currentTarget.dataset.classid;
        const courseId = e.currentTarget.dataset.courseid;
        const courseName = e.currentTarget.dataset.coursename;
        wx.navigateTo({
            url: `/pages/xxt-package/activity/activity?username=${account.username}&password=${account.password}&classId=${classId}&courseId=${courseId}&uid=${account.uid}&courseName=${courseName}`,
        })
    },


    onShareAppMessage() { // 邀请用户
        const userInfo = util.getStorage('userInfo', {});
        return {
            title: '早八不迟到 ~',
            imageUrl: '',
            path: `/pages/tabbar-package/login/login?inviter=${userInfo.uid}`,
        }
    },

    toMiniProgram(e) { // 跳转其他小程序
        console.log("跳转其他小程序", e)
        wx.openEmbeddedMiniProgram({
            'appId': e.currentTarget.dataset.appid,
            'extraData': {},
        }).catch(e => {
            this.showInfo("用户取消打开小程序")
        })
    },

    showOfficial(e) { // 显示引导公众号
        this.setData({
            'showOfficial': true,
        })
    },

    lookImage(e) { // 查看图片
        wx.previewImage({
            urls: this.data.swiperList,
            current: this.data.swiperList[e.detail.index],
        })
    },

    showLoading(msg) {
        wx.showLoading({
            title: msg,
            mask: true,
        })
    },

    hideLoading() {
        wx.hideLoading({
            noConflict: true,
        });
    },

    showInfo(msg, icon = "none") {
        wx.showToast({
            title: msg,
            mask: true,
            icon: icon,
        })
    },
})